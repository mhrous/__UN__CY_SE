export default {
  port: 8888,
  dbUrl: "mongodb://localhost:27017/its",
  duration: 20,
  serverSecritWord: "hi i am server"
};
