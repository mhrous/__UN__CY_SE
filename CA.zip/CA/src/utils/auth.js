import Certifcate from "./certifcate";

export const singIn = data => {};
export const singUp = () => {};
export const createServeCertifcate = () => {};
