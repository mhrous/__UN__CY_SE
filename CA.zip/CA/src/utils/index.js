import { connect } from "./db";

export { connect };
